var player ="O";
var oxList = ["icon://fa-circle-o", "icon://fa-times"];
var colList = ["#1212d9", "#ff000a"];
var bordList = ["","","","","","","","",""];
var comList = [10,10,10,10,10,10,10,10,10];
var comRoll;
onEvent("button1Start", "click", function( ) {
  showElement("label1instructions");
  showElement("button1min");
  hideElement("image1INFO");
  setScreen("screen3Game");
});
onEvent("button1min", "click", function( ) {
  hideElement("label1instructions");
  hideElement("button1min");
  showElement("image1INFO");
});
onEvent("image1INFO", "click", function( ) {
  hideElement("image1INFO");
  showElement("label1instructions");
  showElement("button1min");
});
onEvent("bord1", "click", function( ) {
  upScreen(1);
});
onEvent("bord2", "click", function( ) {
  upScreen(2);
});
onEvent("bord3", "click", function( ) {
  upScreen(3);
});
onEvent("bord4", "click", function( ) {
  upScreen(4);
});
onEvent("bord5", "click", function( ) {
  upScreen(5);
});
onEvent("bord6", "click", function( ) {
  upScreen(6);
});
onEvent("bord7", "click", function( ) {
  upScreen(7);
});
onEvent("bord8", "click", function( ) {
  upScreen(8);
});
onEvent("bord9", "click", function( ) {
  upScreen(9);
});
function upScreen(num) {
  if (bordList[num-1]=="") {
    if (player=="O") {
      setImageURL("bord"+num, oxList[0]);
      setProperty("bord"+num, "icon-color", colList[0]);
      insertItem(bordList, num-1, "o");
      removeItem(bordList, num);
    }
  }
  for (var i = 0; i < 9; i=i+3) {
    if (bordList[i]==bordList[i+1]&&bordList[i]==bordList[i+2]) {
      winUp(i);
    }
  }
  for (var e = 0; e < 3; e++) {
    if (bordList[e]==bordList[(e+3)]&&bordList[e]==bordList[(e+6)]) {
      winUp(e);
    }
  }
  if (bordList[0]==bordList[4]&&bordList[4]==bordList[8]) {
    winUp(4);
  } else if (bordList[2]==bordList[4]&&bordList[4]==bordList[6]) {
    winUp(4);
  }
  if (player=="com") {
      player = "O";
    } else if ((player=="O")) {
      player = "com";
    }
  if (player=="com") {
    comTurn();
  }
}
function winUp(ind) {
  if (bordList[ind]!="") {
    if (bordList[ind]=="x") {
    setText("Lablewinlose", "LOSE");
    } else if (bordList[ind]=="o") {
    setText("Lablewinlose", "WIN");
    }
    setScreen("screen4win");
  }
}
function comTurn() {
  for (var m = 0; m < 9; m=m+3) {
    if (bordList[m]==bordList[(m+1)]) {
   comList[m]=comList[m]+10;
   comList[m+1]=comList[m+1]+10;
    }
  if (bordList[m]==bordList[(m+2)]) {
    comList[m]=comList[m]+10;
    comList[m+2]=comList[m+2]+10;
  }
  }
  for (var e = 0; e < 3; e++) {
    if (bordList[e]==bordList[(e+3)]) {
      comList[e]=comList[e]+10;
      comList[e+3]=comList[e+3]+10;
    }
    if (bordList[e]==bordList[(e+6)]) {
       comList[e]=comList[e]+10;
       comList[e+6]=comList[e+6]+10;
     }
  }
  if (bordList[0]==bordList[4]) {
         comList[0]=comList[0]+10;
         comList[4]=comList[4]+10;
       }
  if (bordList[4]==bordList[8]) {
       comList[4]=comList[4]+10;
       comList[8]=comList[8]+10;
     }
  if (bordList[2]==bordList[4]) {
       comList[2]=comList[2]+10;
       comList[4]=comList[4]+10;
     }
  if (bordList[4]==bordList[6]) {
       comList[4]=comList[4]+10;
       comList[6]=comList[6]+10;
     }
  for (var f = 0; f < 9; f++) {
      if (bordList[f]!="") {
        comList[f]=0;
      }
    }
  for (var x = 1; x < 9; x++) {
   comList[x]=comList[x]+comList[x-1];
  }
  comRoll = randomNumber(0, comList[8]);
  if (comRoll<comList[0]) {
    bordList[0] = "x";
    setImageURL("bord1", oxList[1]);
    setProperty("bord1", "icon-color", "red");
  } else if (comRoll<comList[1]) {
    bordList[1] = "x";
    setImageURL("bord2", oxList[1]);
    setProperty("bord2", "icon-color", "red");
  } else if (comRoll<comList[2]) {
    bordList[2] = "x";
    setImageURL("bord3", oxList[1]);
    setProperty("bord3", "icon-color", "red");
  } else if (comRoll<comList[3]) {
    bordList[3] = "x";
    setImageURL("bord4", oxList[1]);
    setProperty("bord4", "icon-color", "red");
  } else if (comRoll<comList[4]) {
    bordList[4] = "x";
    setImageURL("bord5", oxList[1]);
    setProperty("bord5", "icon-color", "red");
  } else if (comRoll<comList[5]) {
    bordList[5] = "x";
    setImageURL("bord6", oxList[1]);
    setProperty("bord6", "icon-color", "red");
  } else if (comRoll<comList[6]) {
    bordList[6] = "x";
    setImageURL("bord7", oxList[1]);
    setProperty("bord7", "icon-color", "red");
  } else if (comRoll<comList[7]) {
    bordList[7] = "x";
    setImageURL("bord8", oxList[1]);
    setProperty("bord8", "icon-color", "red");
  } else if(comRoll<comList[8]){
    bordList[8] = "x";
    setImageURL("bord9", oxList[1]);
    setProperty("bord9", "icon-color", "red");
  }
  }
  
