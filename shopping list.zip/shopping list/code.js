var food = [];
var newFo = "";
onEvent("addButton1", "click", function( ) {
  newFo = getText("text_input1");
  appendItem(food," "+newFo);
  upScre();
});
onEvent("clearButton2", "click", function( ) {
  food = [];
  upScre();
});
function upScre() {
  setText("textOutputlabel", food);
  setText("text_input1", "");
  setText("amountlistLable", "There are "+food.length+" items on our list.");
}
