var score = 0;
var round = 1;
onEvent("startbutton", "click", function( ) {
  shufPic();
  setScreen("loadingscreen");
});
onEvent("newroundbutton", "click", function( ) {
  setScreen("gamescreen1");
});
onEvent("playroundbutton", "click", function( ) {
  setScreen("gamescreen1");
});
onEvent("gotoresoltsbutton", "click", function( ) {
  setScreen("calculatingscreen");
  setText("foundlabel2", score+"/10");
  setTimeout(function() {
    showElement("calculatinglabel2");
    showElement("calculatingbutton");
  }, 1000);
});
// round work
onEvent("image11", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image12", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image3", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image4", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image5", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image6", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image7", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image8", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("image9", "click", function( ) {
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
onEvent("correctimage", "click", function( ) {
  score = score+1;
  round = round+1;
  shufPic();
  setScreen("loadingscreen");
});
//calulate and show score
onEvent("calculatingbutton", "click", function( ) {
  setScreen("resoltsscreen");
});
//playagian button work
onEvent("playagainbutton", "click", function( ) {
  setScreen("startscreen");
});

function shufPic() {
  hideElement("newroundbutton");
  hideElement("playroundbutton");
  hideElement("gotoresoltsbutton");
  setText("roundlabel", "Round "+round);
  setText("scorelabel", "Score "+score);
  setPosition("image11", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image7", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image9", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image5", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image4", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image12", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image6", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image3", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("image8", randomNumber(10, 300), randomNumber(40, 400), randomNumber(40, 500), randomNumber(40, 500));
  setPosition("correctimage", randomNumber(100, 250), randomNumber(100, 350), randomNumber(200, 500), randomNumber(200, 500));
  if (round==10) {
    showElement("gotoresoltsbutton");
  } else if (round==1) {
    showElement("playroundbutton");
  } else {
    showElement("newroundbutton");
  }
}
