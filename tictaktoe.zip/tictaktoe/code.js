var player ="O";
var oxList = ["icon://fa-circle-o", "icon://fa-times"];
var colList = ["#1212d9", "#ff000a"];
var bacoList = ["#AAEBDF","#FB4F4F"];
var bordList = ["", "","","","","","","",""];
onEvent("button1Start", "click", function( ) {
  showElement("label1instructions");
  showElement("button1min");
  hideElement("image1INFO");
  setProperty("screen3Game", "background-color", bacoList[0]);
  setText("whoturnlabel", "It is O turn");
  setScreen("screen3Game");
});
onEvent("button1min", "click", function( ) {
  hideElement("label1instructions");
  hideElement("button1min");
  showElement("image1INFO");
});
onEvent("image1INFO", "click", function( ) {
  hideElement("image1INFO");
  showElement("label1instructions");
  showElement("button1min");
});
onEvent("bord1", "click", function( ) {
  upScreen(1);
});
onEvent("bord2", "click", function( ) {
  upScreen(2);
});
onEvent("bord3", "click", function( ) {
  upScreen(3);
});
onEvent("bord4", "click", function( ) {
  upScreen(4);
});
onEvent("bord5", "click", function( ) {
  upScreen(5);
});
onEvent("bord6", "click", function( ) {
  upScreen(6);
});
onEvent("bord7", "click", function( ) {
  upScreen(7);
});
onEvent("bord8", "click", function( ) {
  upScreen(8);
});
onEvent("bord9", "click", function( ) {
  upScreen(9);
});
function upScreen(num) {
  if (bordList[num-1]=="") {
    if (player=="O") {
      setImageURL("bord"+num, oxList[0]);
      setProperty("bord"+num, "icon-color", colList[0]);
      insertItem(bordList, num-1, "o");
      removeItem(bordList, num);
    } else if ((player=="X")) {
      setImageURL("bord"+num, oxList[1]);
      setProperty("bord"+num, "icon-color", "red");
      insertItem(bordList, num-1, "x");
      removeItem(bordList, num);
    }
    if (player=="X") {
      player = "O";
      setProperty("screen3Game", "background-color", bacoList[0]);
    } else if ((player=="O")) {
      player = "X";
      setProperty("screen3Game", "background-color", bacoList[1]);
    }
  }
  setText("whoturnlabel", "it is "+player+" turn");
  for (var i = 0; i < 9; i=i+3) {
    if (bordList[i]==bordList[i+1]&&bordList[i]==bordList[i+2]) {
      winUp(i);
    }
  }
  for (var e = 0; e < 3; e++) {
    if (bordList[e]==bordList[(e+3)]&&bordList[e]==bordList[(e+6)]) {
      winUp(e);
    }
  }
  if (bordList[0]==bordList[4]&&bordList[4]==bordList[8]) {
    winUp(4);
  } else if (bordList[2]==bordList[4]&&bordList[4]==bordList[6]) {
    winUp(4);
  }
}
function winUp(ind) {
  if (bordList[ind]!="") {
    if (bordList[ind]=="x") {
    setProperty("imageWinner", "icon-color", colList[1]);
    setProperty("imageWinner", "image", oxList[1]);
    } else if (bordList[ind]=="o") {
    setProperty("imageWinner", "icon-color", colList[0]);
    setProperty("imageWinner", "image", oxList[0]);
    }
    setScreen("screen4win");
  }
}
