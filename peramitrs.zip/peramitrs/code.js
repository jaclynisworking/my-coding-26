var num = 0;
onEvent("button1", "click", function( ) {
  add(1);
});
onEvent("button3", "click", function( ) {
  add(3);
});
onEvent("button7", "click", function( ) {
  add(7);
});
function add(addNum) {
  num = num+addNum;
  setText("lableNum", num);
}
