var shootPlayer = "";
var npcShoot = "";
onEvent("startbutton", "click", function( ) {
  setScreen("transtonscrean");
  tranAni();
  showElement("next1button");
});
//transiton screen code
onEvent("next1button", "click", function( ) {
  hideElement("next1button");
  tranAni();
  showElement("next2button");
});
onEvent("next2button", "click", function( ) {
  hideElement("next2button");
  tranAni();
  showElement("next3button");
});
onEvent("next3button", "click", function( ) {
  hideElement("next3button");
  tranAni();
  showElement("next4button");
});
onEvent("next4button", "click", function( ) {
  hideElement("next4button");
  tranAni();
  setTimeout(function() {
    setScreen("gamescrean");
  }, 2000);
});
//attackplayer chose
onEvent("playerAttackdropdown", "click", function( ) {
  shootPlayer = getText("playerAttackdropdown");
  if (shootPlayer=="Rock") {
    setImageURL("attackPlayer", "icon://fa-hand-rock-o");
  } else if (shootPlayer=="Paper") {
    setImageURL("attackPlayer", "icon://fa-hand-paper-o");
  } else if (shootPlayer=="Scissors") {
    setImageURL("attackPlayer", "icon://fa-hand-scissors-o");
  }
});
onEvent("attackButton", "click", function( ) {
  if (shootPlayer=="Rock") {
    setImageURL("pcAttackimage", "icon://fa-hand-rock-o");
  } else if (shootPlayer=="Paper") {
    setImageURL("pcAttackimage", "icon://fa-hand-paper-o");
  } else if (shootPlayer=="Scissors") {
    setImageURL("pcAttackimage", "icon://fa-hand-scissors-o");
  }
  npcAtt();
  if (npcShoot=="Rock") {
    setImageURL("npcAttckimage", "icon://fa-hand-rock-o");
  } else if (npcShoot=="Paper") {
    setImageURL("npcAttckimage", "icon://fa-hand-paper-o");
  } else if (npcShoot=="Scissors") {
    setImageURL("npcAttckimage", "icon://fa-hand-scissors-o");
  }
  setScreen("screen2attack");
  whowin();
  setTimeout(function() {
    showElement("playagain");
  }, 5000);
});
//win addd playagain
//keep score?
//make another miniegame?
onEvent("playagain", "click", function( ) {
  setScreen("startgamescrean");
});



function tranAni() {
  setPosition("transitonhand1", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  setPosition("transitonhand2", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  setTimeout(function() {
    setPosition("transitonhand4", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
    setPosition("transitonhand5", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  }, 1000);
  setPosition("transitonhand3", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  setTimeout(function() {
    setPosition("transitonhand6", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
    setPosition("transitonhand7", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  }, 100);
  setPosition("transitonhand8", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  setPosition("transitonhand9", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  setTimeout(function() {
    setPosition("transitonhand10", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  }, 1000);
  setPosition("transitonhand11", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
  setPosition("transitonhand12", randomNumber(1, 315), randomNumber(1, 400), randomNumber(30, 300), randomNumber(30, 300));
}
//have cp chose attack
function npcAtt() {
  npcShoot = randomNumber(1, 3);
  if (npcShoot==1) {
    npcShoot = "Rock";
  } else if (npcShoot==2) {
    npcShoot = "Paper";
  } else if (npcShoot==3) {
    npcShoot = "Scissors";
  }
}
function whowin() {
  if (shootPlayer=="Rock") {
    if (npcShoot=="Rock") {
      setText("attackwinloselable", "It Is A Tie");
    } else if (npcShoot=="Paper") {
      setText("attackwinloselable", "You Lose");
    } else if ((npcShoot=="Scissors")) {
      setText("attackwinloselable", "You Win");
    }
  } else if (shootPlayer=="Paper") {
    if (npcShoot=="Rock") {
      setText("attackwinloselable", "You Win");
    } else if (npcShoot=="Paper") {
      setText("attackwinloselable", "It Is A Tie");
    } else if ((npcShoot=="Scissors")) {
      setText("attackwinloselable", "You Lose");
    }
  } else if (shootPlayer=="Scissors") {
    if (npcShoot=="Rock") {
      setText("attackwinloselable", "You Lose");
    } else if (npcShoot=="Paper") {
      setText("attackwinloselable", "You Win");
    } else if ((npcShoot=="Scissors")) {
      setText("attackwinloselable", "It Is A Tie");
    }
  }
  setTimeout(function() {
    showElement("attackwinloselable");
  }, 3000);
}
