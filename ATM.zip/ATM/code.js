var balance = 1000;
var moneyInput = "";
onEvent("withdrawbutton", "click", function( ) {
  moneyInput = getNumber("cashinput");
  balance = balance-moneyInput;
  updateScrean();
});
onEvent("Depositbutton", "click", function( ) {
  moneyInput = getNumber("cashinput");
  balance = balance+moneyInput;
  updateScrean();
});
function updateScrean() {
  setText("balancelable", "Balance: $"+ balance);
  setText("cashinput", "");
  if (balance >= 10000) {
    setText("warningLable", "thark you for being platinum-tier");
  } else if (balance >= 7000) {
    setText("warningLable", "thark you for being gold-tier");
  } else if (balance >= 5000) {
    setText("warningLable", "thark you for being silver-tier");
  } else if (balance >= 3000) {
    setText("warningLable", "thark you for being bronze-tier");
  } else if ((balance >= 0)) {
    setText("warningLable", "hello customer");
  } else if (balance < 0) {
    setText("warningLable", "warning overdraft");
  } else {
    setText("warningLable", "error");
  }
}
